

/* 资源与路由配置  */

module.exports = {
	
	staticFile: ['css', 'font', 'img', "js"],
	
	'/': {
		title: '首页',
		pathname: 'index.html'
	}
}
