/**
 * Created by pangmengchen on 12/4/16.
 */
var router = require('express').Router();

router.post('/query', function (req, res) {
    var data=['Moring','Tom','Jack','Mot','Saturday'];
    return returnSUCCESS(res,data);
});

router.get('/index',function (req,res) {
    res.render('my');
});

module.exports = router;