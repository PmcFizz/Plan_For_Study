/**
 * Created by pangmengchen on 12/4/16.
 */
(function () {
    $(document).ready(function () {
        $.ajax({
            type:"post",
            url:'/moring/query',
            data:{
                name:'Fizz',
                age:24
            },
            dataType:"json",
            success:function (res) {
                console.log(res);
            }
        })
    })
})();